package com.cs360.projectthreeinventoryapp;

import static com.cs360.projectthreeinventoryapp.Inventory.nonDeletedItems;

import android.content.Context;
import android.content.res.Resources;
import android.view.View;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;
//Repository class to get data for recycler view
public class InventoryRepository {
    private static InventoryRepository instance;
    private List<Inventory> mItems;
    private SQLiteManager db;

    public static InventoryRepository getInstance(Context context) {
        if (instance == null) {
            instance = new InventoryRepository(context);
        }
        return instance;
    }

    //function creates Arraylist from Inventory class to be passed to recyclerview list fragment
    private InventoryRepository(Context context) {
        mItems = new ArrayList<>();
        Resources res = context.getResources();
        Inventory items = new Inventory();
        mItems = nonDeletedItems();



    }

    //function to get items in lists
    public List<Inventory> getItems() {
        return mItems;
    }

    public Inventory getItems(int itemId) {
        for (Inventory item : mItems) {
            if (item.getId() == itemId) {
                return item;
            }
        }
        return null;
    }






}

