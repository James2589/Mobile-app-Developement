package com.cs360.projectthreeinventoryapp;

import static android.os.Looper.getMainLooper;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


public class ListFragment extends Fragment {
//initialize widgets
    private FloatingActionButton fab;
    ArrayList <Inventory> items;
    ArrayList <Inventory> mArrayList;
    private SQLiteManager db;
//Creates recycler view
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_list, container, false);

        // Click listener for the RecyclerView
        View.OnClickListener onClickListener = itemView -> {

            // Create fragment arguments containing the selected item ID
            int selectedItemId = (int) itemView.getTag();
            Bundle args = new Bundle();
            args.putInt(DetailFragment.ARG_ITEM_ID, selectedItemId);

            // Replace list with details
            Navigation.findNavController(itemView).navigate(R.id.show_item_detail, args);
        };

        // Send items to RecyclerView
        Inventory.test();
        RecyclerView recyclerView = rootView.findViewById(R.id.item_list);
        List<Inventory> items = InventoryRepository.getInstance(requireContext()).getItems();
        recyclerView.setAdapter(new ItemAdapter(items, onClickListener));
        fab = rootView.findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openAddItem();
            }
        });

        return rootView;
    }


//function to open item creation activity
    public void openAddItem(){
        Intent intent = new Intent(this.getContext(), AddItem.class);
        startActivity(intent);
    }

    private void run() {

    }

    //recycler view adapter class
    private class ItemAdapter extends RecyclerView.Adapter<ItemHolder> {

        private final List<Inventory> mItems;
        private final View.OnClickListener mOnClickListener;


        public ItemAdapter(List<Inventory> items, View.OnClickListener onClickListener) {
            mItems = items;
            mOnClickListener = onClickListener;

        }

        @NonNull
        @Override
        public ItemHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(getActivity());
            return new ItemHolder(layoutInflater, parent);
        }

        @Override
        public void onBindViewHolder(ItemHolder holder, int position) {
            Inventory item = mItems.get(position);
            holder.bind(item);
            holder.itemView.setTag(item.getId());
            holder.itemView.setOnClickListener(mOnClickListener);
        }

        @Override
        public int getItemCount() {
            return mItems.size();
        }
    }


    private static class ItemHolder extends RecyclerView.ViewHolder {

        private final TextView mNameTextView;
        //private final TextView mAmountTextView;
        //private final ImageButton mRemoveItem;
        //private final ImageButton mAddItem;


        public ItemHolder(LayoutInflater inflater, ViewGroup parent) {
            super(inflater.inflate(R.layout.list_inventory_item, parent, false));
            mNameTextView = itemView.findViewById(R.id.item_name);

        }

        public void bind(Inventory item) {
            mNameTextView.setText(item.getItem());



        }

    }



}
