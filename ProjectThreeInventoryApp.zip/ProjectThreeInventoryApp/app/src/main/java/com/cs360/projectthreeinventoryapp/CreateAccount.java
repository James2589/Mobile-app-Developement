package com.cs360.projectthreeinventoryapp;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Button;
import android.os.Bundle;

import com.cs360.projectthreeinventoryapp.R;
import com.cs360.projectthreeinventoryapp.Users;

import java.util.ArrayList;

public class CreateAccount extends AppCompatActivity {
//initializes variables and widgets
    private Users user;

    private EditText nUsername;
    private EditText nPassword;
    private Button nCreate;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);

        nUsername = findViewById(R.id.username_input);
        nPassword = findViewById(R.id.password_input);
        nCreate = (Button) findViewById(R.id.create_button);

        nCreate.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
               saveUser(v);
            }
        });

    }

    private void checkForEditUser(){
        Intent previousIntent = getIntent();
        int passedUserId = previousIntent.getIntExtra(Users.USER_EDIT_EXTRA, -1);
        Users selectedUser = Users.getUserForId(passedUserId);

        if(selectedUser != null){
            nUsername.setText(selectedUser.getUsername());
            nPassword.setText(selectedUser.getPassWord());
        }
    }
//saves new user to database
    public void saveUser(View view){
        SQLiteManager sqLiteManager = SQLiteManager.instanceOfDatabase(this);
        String username = String.valueOf(nUsername.getText());
        String password = String.valueOf(nPassword.getText());

        int id = Users.usersArrayList.size();
        Users newUser = new Users(id, username, password);
        Users.usersArrayList.add(newUser);
        sqLiteManager.addUserToDB(newUser);

        openUserLogin();
    }

    //test used when checking database connection
    public void testUser(Users user){
        SQLiteManager sqLiteManager = SQLiteManager.instanceOfDatabase(this);
        Users testUser = new Users();
        testUser.setUsername("admin");
        testUser.setPassword("1234");
        sqLiteManager.addUserToDB(testUser);
    }
//take user to login page
    public void openUserLogin(){
        Intent intent = new Intent(this, UserLogin.class);
        startActivity(intent);
    }


}
