package com.cs360.projectthreeinventoryapp;

import java.util.ArrayList;

public class Users {
//intilize user variables
    public static ArrayList<Users> usersArrayList = new ArrayList<>();
    public static String USER_EDIT_EXTRA = "userEdit";

    private int id;
    private String userName;
    private String passWord;

    public Users(){}

    public Users(int id, String userName, String passWord){
        this.id = id;
        this.userName = userName;
        this.passWord = passWord;
    }

    //get the id per user
    public static Users getUserForId(int passedUserId){
        for (Users user : usersArrayList){
            if(user.getId() == passedUserId)
                return user;
        }
        return null;
    }

    //get username per user
    public static Users getUserForUsername(String userName) {
        for (Users user : usersArrayList) {
            if (user.getUsername() == userName) {
                return user;
            }
        }
        return null;
    }

//Setters and Getters
    public int getId(){
        return id;
    }

    public void setId(int id){
        this.id = id;
    }

    public String getUsername(){
        return userName;
    }
    public void setUsername(String userName){
        this.userName = userName;
    }
    public String getPassWord(){
        return passWord;
    }

    public void setPassword(String passWord){
        this.passWord = passWord;
    }

    public static ArrayList<Users> getUsers(){
        ArrayList<Users> testUsers = new ArrayList<>();

        testUsers.add(new Users(0,"admin", "1234" ));

        return testUsers;
    }

}

