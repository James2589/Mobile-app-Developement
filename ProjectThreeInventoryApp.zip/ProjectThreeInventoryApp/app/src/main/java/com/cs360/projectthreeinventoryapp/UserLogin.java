package com.cs360.projectthreeinventoryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Button;
import android.os.Bundle;

public class UserLogin extends AppCompatActivity {

    //initialize widgets
    private Users user;
    private EditText mUsername;
    private EditText mPassword;
    private Button mLogin;
    private Button mCreateAccount;
    private SQLiteManager db = new SQLiteManager(this);



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //Create user login screen
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_login);

        //variables to take user input from widgets
        mUsername = findViewById(R.id.username_input);
        mPassword = findViewById(R.id.password_input);
        mLogin = (Button) findViewById(R.id.login_button);
        mCreateAccount = (Button) findViewById(R.id.create_button);
        //open SMS dialog
        openDialog();


         //Onclick listens to take user to main Dashboard
        mLogin.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {

                openInventory();
            }
        });
        //Onclick listens to take user to account create
        mCreateAccount.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                openCreateAccount();
            }
        });
    }

    //Function opens Inventory Activity
    public void openInventory(){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    //Function opens Account creation activity
    public void openCreateAccount(){
        Intent intent = new Intent(this, CreateAccount.class);
        startActivity(intent);
    }

    //Funciton opens dialog fragment
    public void openDialog(){
        SmsDialog smsDialog = new SmsDialog();
        smsDialog.show(getSupportFragmentManager(), "SMS Dialog");
    }




}