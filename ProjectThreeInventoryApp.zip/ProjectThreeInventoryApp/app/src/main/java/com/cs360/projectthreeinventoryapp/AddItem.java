package com.cs360.projectthreeinventoryapp;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Button;
import android.os.Bundle;


import java.util.ArrayList;
public class AddItem extends AppCompatActivity{

    private Inventory item;

    private EditText addName;
    private EditText addAmount;
    private EditText addLocation;
    private EditText addDescription;
    private Button addButton;
    private Inventory selectedItem;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_item);
        checkForEditItem();
        //initialize widgets
        addName = findViewById(R.id.add_name);
        addAmount = findViewById(R.id.add_amount);
        addLocation = findViewById(R.id.add_location);
        addDescription = findViewById(R.id.add_description);
        addButton = findViewById(R.id.add_item);

        addButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                saveItem(v);
            }
        });

    }
//checks if items have been changed
    private void checkForEditItem(){
        Intent previousIntent = getIntent();
        int passedItemId = previousIntent.getIntExtra(Inventory.ITEM_EDIT_EXTRA, -1);
        selectedItem = Inventory.getItemForId(passedItemId);

        if(selectedItem != null){
            addName.setText(selectedItem.getItem());
            addAmount.setText(selectedItem.getAmount());
            addLocation.setText(selectedItem.getLocation());
            addDescription.setText(selectedItem.getDescription());
        }
    }
//saves item to database
    public void saveItem(View view){
        SQLiteManager sqLiteManager = SQLiteManager.instanceOfDatabase(this);
        String name = String.valueOf(addName.getText());
        String amount = String.valueOf(addAmount.getText());
        String location = String.valueOf(addLocation.getText());
        String description = String.valueOf(addDescription.getText());

        int id = Inventory.itemArrayList.size();
        Inventory newItem = new Inventory(id, name, amount, location, description);
        Inventory.itemArrayList.add(newItem);
        sqLiteManager.addItemToDB(newItem);

        openInventory();
    }
//takes user back to main page upon successful item creation
    public void openInventory(){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

}
