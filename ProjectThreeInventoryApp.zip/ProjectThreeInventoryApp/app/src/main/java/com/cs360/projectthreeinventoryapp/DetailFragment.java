package com.cs360.projectthreeinventoryapp;


import android.content.Context;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.ImageButton;
import android.widget.Button;
import java.util.Date;

public class DetailFragment extends Fragment {
//Detail fragment initializes variables
    private Inventory mItem;
    public static final String ARG_ITEM_ID = "item_id";
    private Inventory selectedItem;


    public DetailFragment() {
        // Required empty public constructor
    }
//creates detail fragment
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        int itemId = 1;

        // Get the item ID from the fragment arguments
        Bundle args = getArguments();
        if (args != null) {
            itemId = args.getInt(ARG_ITEM_ID);
        }

        // Get the selected item
        mItem = InventoryRepository.getInstance(requireContext()).getItems(itemId);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_detail, container, false);
//variables to give widgets proper item information
        if (mItem != null) {
            TextView nameTextView = rootView.findViewById(R.id.item_name);
            nameTextView.setText(mItem.getItem());

            TextView amountTextView = rootView.findViewById(R.id.item_amount);
            amountTextView.setText(mItem.getAmount());

            TextView descriptionTextView = rootView.findViewById(R.id.item_description);
            descriptionTextView.setText(mItem.getDescription());

            TextView locationTextView = rootView.findViewById(R.id.item_location);
            locationTextView.setText(mItem.getLocation());
        }
//remove item amount
        ImageButton removeAmount = rootView.findViewById(R.id.delete_item_amount);
        removeAmount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int amount = Integer.parseInt(mItem.getAmount());
                amount -= 1;
                mItem.setAmount(String.valueOf(amount));
            }
        });
//add item amount
        ImageButton addAmount = rootView.findViewById(R.id.add_item_amount);
        addAmount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int amount = Integer.parseInt(mItem.getAmount());
                amount += 1;
                mItem.setAmount(String.valueOf(amount));
            }
        });
//unfinished delete item from inventory
        Button deleteButton = (Button) rootView.findViewById(R.id.delete_button);
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //deleteItem(v);
            }
        });


        return rootView;
    }


   // public void deleteItem(View view){
     //   selectedItem.setDeleted(new Date());
       // SQLiteManager sqLiteManager = SQLiteManager.instanceOfDatabase(this);
        //sqLiteManager.updateItemInDB(selectedItem);
        //finish();
    //}
}
