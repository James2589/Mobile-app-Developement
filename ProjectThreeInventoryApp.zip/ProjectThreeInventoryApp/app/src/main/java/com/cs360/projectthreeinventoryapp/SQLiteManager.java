package com.cs360.projectthreeinventoryapp;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class SQLiteManager extends SQLiteOpenHelper {

    private static SQLiteManager sqliteManager;
    private static final String DATABASE_NAME = "ItemsDB";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_NAME = "Items";
    private static final String COUNTER = "Counter";

    private static final String ID_FIELD = "id";
    private static final String ITEM_FIELD = "item_name";
    private static final String AMOUNT_FIELD = "amount";
    private static final String LOCATION_FIELD = "location";
    private static final String DESC_FIELD ="description";
    private static final String DELETED_FIELD = "deleted";
    private static final String TABLE_NAMEU = "user";
    private static final String IDU_FIELD = "id";
    private static final String USERNAME_FIELD = "username";
    private static final String PASSWORD_FIELD = "password";

    @SuppressLint("SimpleDateFormat")
    private static final DateFormat dateFormat = new SimpleDateFormat("MM-DD-YYYY HH:mm:ss");

    public SQLiteManager(Context context){
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    public static SQLiteManager instanceOfDatabase(Context context){
        if(sqliteManager == null){
            sqliteManager = new SQLiteManager(context);
        }
        return sqliteManager;
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        StringBuilder sql;
        StringBuilder sqlU;
        sql = new StringBuilder().append("CREATE TABLE ")
                .append(TABLE_NAME)
                .append("(")
                .append(COUNTER)
                .append(" Integer PRIMARY KEY AUTOINCREMENT, ")
                .append(ID_FIELD)
                .append(" int, ")
                .append(ITEM_FIELD)
                .append(" TEXT, ")
                .append(AMOUNT_FIELD)
                .append(" TEXT, ")
                .append(LOCATION_FIELD)
                .append(" TEXT, ")
                .append(DESC_FIELD)
                .append(" TEXT, ")
                .append(DELETED_FIELD)
                .append(" TEXT)");

        sqlU = new StringBuilder().append("CREATE TABLE ")
                        .append(TABLE_NAMEU)
                        .append("(")
                        .append(IDU_FIELD)
                        .append(" Integer PRIMARY KEY AUTOINCREMENT, ")
                        .append(USERNAME_FIELD)
                        .append(" TEXT, ")
                        .append(PASSWORD_FIELD)
                        .append(" TEXT)");

        db.execSQL(sqlU.toString());
        db.execSQL(sql.toString());


    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAMEU);
        onCreate(db);
    }

    public void addItemToDB(Inventory item){
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();

        ContentValues contentValues = new ContentValues();
        contentValues.put(ID_FIELD, item.getId());
        contentValues.put(ITEM_FIELD, item.getItem());
        contentValues.put(AMOUNT_FIELD, item.getAmount());
        contentValues.put(LOCATION_FIELD, item.getLocation());
        contentValues.put(DESC_FIELD, item.getDescription());
        contentValues.put(DELETED_FIELD, getStringFromDate(item.getDeleted()));

        sqLiteDatabase.insert(TABLE_NAME, null, contentValues);
    }

    public void addUserToDB(Users user){
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();

        ContentValues contentValues = new ContentValues();
        contentValues.put(IDU_FIELD, user.getId());
        contentValues.put(USERNAME_FIELD, user.getUsername());
        contentValues.put(PASSWORD_FIELD, user.getPassWord());

        sqLiteDatabase.insert(TABLE_NAMEU, null, contentValues);
    }

    public ArrayList<Inventory> populateInventoryListArray()
    {
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();

        try (Cursor result = sqLiteDatabase.rawQuery("SELECT * FROM " + TABLE_NAME, null))
        {
            if(result.getCount() != 0)
            {
                while (result.moveToNext())
                {
                    int id = result.getInt(1);
                    String itemName = result.getString(2);
                    String amount = result.getString(3);
                    String location = result.getString(4);
                    String description = result.getString(5);
                    String stringDeleted = result.getString(6);
                    Date deleted = getDateFromString(stringDeleted);
                    Inventory item = new Inventory(id, itemName, amount, location, description, deleted);
                    Inventory.itemArrayList.add(item);
                }
            }
        }


        return null;
    }

    public ArrayList<Users> populateUserListArray() {
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();

        try (Cursor result = sqLiteDatabase.rawQuery("SELECT * FROM " + TABLE_NAMEU, null)) {
            if (result.getCount() != 0) {
                while (result.moveToNext()) {
                    int id = result.getInt(0);
                    String userName = result.getString(1);
                    String passWord = result.getString(2);
                    Users user = new Users(id, userName, passWord);
                    Users.usersArrayList.add(user);
                }
            }
        }
        return null;
    }

    public void updateItemInDB(Inventory item){
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(ID_FIELD, item.getId());
        contentValues.put(ITEM_FIELD, item.getItem());
        contentValues.put(AMOUNT_FIELD, item.getAmount());
        contentValues.put(LOCATION_FIELD, item.getLocation());
        contentValues.put(DESC_FIELD, item.getDescription());
        contentValues.put(DELETED_FIELD, getStringFromDate(item.getDeleted()));

        sqLiteDatabase.update(TABLE_NAME, contentValues, ID_FIELD + " =?", new String[]{String.valueOf(item.getId())});
    }

    public void updateUserinDB(Users user){
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(IDU_FIELD, user.getId());
        contentValues.put(USERNAME_FIELD, user.getUsername());
        contentValues.put(PASSWORD_FIELD, user.getPassWord());

        sqLiteDatabase.update(TABLE_NAMEU, contentValues, IDU_FIELD + " =?", new String[]{String.valueOf(user.getId())});

    }


    private String getStringFromDate(Date date){
        if(date == null){
            return null;
        }
        return dateFormat.format(date);
    }

    private Date getDateFromString(String string){
        try{
            return dateFormat.parse(string);
        }
        catch(ParseException | NullPointerException e)
        {
            return null;
        }
    }

}
