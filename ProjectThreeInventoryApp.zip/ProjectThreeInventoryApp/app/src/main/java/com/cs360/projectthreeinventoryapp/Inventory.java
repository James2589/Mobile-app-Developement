package com.cs360.projectthreeinventoryapp;

import static androidx.fragment.app.FragmentManager.TAG;

import android.annotation.SuppressLint;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;
import java.util.Date;
public class Inventory {
//initialize Inventory variables
    public static ArrayList<Inventory> itemArrayList = new ArrayList<>();
    public static String ITEM_EDIT_EXTRA = "itemEdit";
    private int id;
    private String itemName;
    private String invAmount;
    private String description;
    private String location;
    private Date deleted;
//Inventory constructors
    public Inventory() {}

    public Inventory(int id, String item, String amount, String location, String description, Date deleted) {
        this.id = id;
        this.itemName = item;
        this.invAmount = amount;
        this.location = location;
        this.description = description;
        this.deleted = deleted;
    }

    public Inventory(int id, String item, String amount, String location, String description) {
        this.id = id;
        this.itemName = item;
        this.invAmount = amount;
        this.location = location;
        this.description = description;
        deleted = null;
    }

    //get item for specified id
    public static Inventory getItemForId(int passedUserId){
        for (Inventory item : itemArrayList){
            if(item.getId() == passedUserId)
                return item;
        }
        return null;
    }

    //creates arraylist for items that havent been deleted
    //this is meant to allow for soft deletes
    public static ArrayList<Inventory> nonDeletedItems(){
        ArrayList<Inventory> nonDeleted = new ArrayList<>();
        for(Inventory item : itemArrayList){
            if(item.getDeleted() == null){
                nonDeleted.add(item);
            }
        }
        return nonDeleted;
    }

    //test function to test used during testing of databasea connection
    @SuppressLint("RestrictedApi")
    public static void test(){
        for(Inventory item : itemArrayList){
            Log.d(TAG, "inserted item");
        }
    }

    //setters and getters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getItem() {
        return itemName;
    }

    public void setItem(String item) {
        this.itemName = item;
    }

    public String getAmount(){
        return invAmount;
    }

    public void setAmount(String amount){
        this.invAmount = amount;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public Date getDeleted(){
        return deleted;
    }

    public void setDeleted(Date deleted){
        this.deleted = deleted;
    }
}

